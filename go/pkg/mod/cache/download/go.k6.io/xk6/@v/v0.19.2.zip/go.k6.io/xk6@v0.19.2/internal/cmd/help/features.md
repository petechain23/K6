Main features

- [ ] Create new extension skeleton (project scaffolding)
- [x] Build k6 with extensions
- [x] Run k6 with extensions
- [x] Check the extension for compliance (lint)
- [ ] Provide reusable GitHub workflows
- [x] Distribute xk6 as a Dev Container Feature
