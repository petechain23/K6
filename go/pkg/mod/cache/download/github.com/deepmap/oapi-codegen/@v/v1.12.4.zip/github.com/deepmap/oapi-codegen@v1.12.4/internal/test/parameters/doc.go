package parameters

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --config=config.yaml parameters.yaml
