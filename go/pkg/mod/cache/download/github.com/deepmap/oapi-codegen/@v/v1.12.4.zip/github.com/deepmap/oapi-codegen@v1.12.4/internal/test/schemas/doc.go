package schemas

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --config=config.yaml schemas.yaml
