// +build tools

package tools

import (
	_ "github.com/matryer/moq"
)
