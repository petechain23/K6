package head_digit_of_httpheader

//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --config=config.ext.yaml spec-ext.yaml
//go:generate go run github.com/deepmap/oapi-codegen/cmd/oapi-codegen --config=config.base.yaml spec-base.yaml
