exports.bar = require('bar-pkg').bar
